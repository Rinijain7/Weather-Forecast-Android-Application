package weather.rini.com.weatherforecast.model;

/**
 * Created by Rini on 11/22/2015.
 */
public class LatLong {
    Float lat;
    Float lng;

    public Float getLng() {
        return lng;
    }

    public void setLng(Float lng) {
        this.lng = lng;
    }

    public Float getLat() {

        return lat;
    }

    public void setLat(Float lat) {
        this.lat = lat;
    }
}
